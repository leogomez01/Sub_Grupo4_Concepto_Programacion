//Import of all classes and utilities from the java. package

package productoVentas;

import java.util.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

@SuppressWarnings("unused")

public class GenerateInfoFiles { // Class that generates the information of the requested files

	// Creation of the Product Class, whic its attributes.
	static class Product {
		String idProduct;
		String nameProduct;
		double priceByUnit;

		// Constructor method of the product class.
		public Product(String idProduct, String nameProduct, double priceByUnit) {
			this.idProduct = idProduct;
			this.nameProduct = nameProduct;
			this.priceByUnit = priceByUnit;
		}
	}

	// Creation of the Seller class, whic its attributes.
	static class Seller {
		String documentType;
		String documentNumber;
		String namesSeller;
		String surnamesSeller;

		// Constructor method of the Seller class.
		public Seller(String documentType, String documentNumber, String namesSeller, String surnamesSeller) {
			this.documentType = documentType;
			this.documentNumber = documentNumber;
			this.namesSeller = namesSeller;
			this.surnamesSeller = surnamesSeller;
		}

	}

	// Creation of the Product Sales, whic its attributes.
	static class Sales {
		Seller seller;
		Product product;
		int amount;
		double totalSalesProduct;

		// Constructor method of the Sales class.
		public Sales(Seller seller, Product product, int amount, double totalSalesProduct) {
			this.seller = seller;
			this.product = product;
			this.amount = amount;
			this.totalSalesProduct = totalSalesProduct;
		}

		// Method of obtaining total sales
		double getTotalsSales() {
			return product.priceByUnit * amount;
		}
	}

	// Creation of the main method
	public static void main(String[] args) {

		// Generating a seller list array
		List<Seller> seller = new ArrayList<>(Arrays.asList(new Seller("CC", "1001", "Juan", "Perez"),
				new Seller("CC", "1002", "Ana", "Gomez"), new Seller("CC", "1003", "Carlos", "Martinez"),
				new Seller("CC", "1004", "Luisa", "Rodriguez"), new Seller("CC", "1005", "Pedro", "Lopez"),
				new Seller("CC", "1006", "Andrea", "Bedoya"), new Seller("CC", "1007", "Santiago", "Vera"),
				new Seller("CC", "1008", "Sebastian", "Ruiz"), new Seller("CC", "1009", "Lina", "Velez")));

		// Generating a product list array
		List<Product> product = new ArrayList<>(
				Arrays.asList(new Product("P001", "Refrigerador", 1800000), new Product("P002", "Lavadora", 650000),
				new Product("P003", "Microondas", 350000), new Product("P004", "Licuadora", 200000),
				new Product("P005", "Horno electrico", 250000), new Product("P006", "Tostadora", 80000),
				new Product("P007", "Cafetera", 60000), new Product("P008", "Aspiradora", 120000),
				new Product("P009", "Plancha", 70000), new Product("P010", "Ventilador", 65000),
				new Product("P012", "celular", 70000), new Product("P011", "Base Cama", 65000),
				new Product("P013", "Portatil", 170000), new Product("P014", "Diadema inalambrica", 500000)));
			

		// Generating a Sales list array
		List<Sales> sales = new ArrayList<>();
		Random random = new Random();
		for (Product product2 : product) {
			Seller seller2 = seller.get(random.nextInt(seller.size()));
			int amount = 1 + random.nextInt(10);
			double totalSalesProduct = product2.priceByUnit * amount;
			sales.add(new Sales(seller2, product2, amount, totalSalesProduct));
		}
	
		
		// Called the method that generates the product file
		generateProductFile(product);

		// Called the method that generates the sellers file
		generateSellerFile(seller);

		// Called the method that generates the Sales file
		generateSalesFile(sales);
		
		// Called the method that generates the SalesMenReport file
		generateSalesMenReportFile (sales);
		
		// Called the method that generates the ProdctSalesReport file
		generateProductSalesReportFile(sales);
		
		// Called the method that generates the SalesBySellerFiles file
		generateSalesBySellerFiles(sales);	
				
	}

	// Method that generates the product flat file
	private static void generateProductFile(List<Product> product) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("products.txt"))) {
			for (Product products : product) {
				writer.write(products.idProduct + "," + products.nameProduct + "," + products.priceByUnit + "\n");
			}
			// Completion message with the successful procedure
			System.out.println("Products file generated successfully.");

			// Completion message with the procedure with error
		} catch (IOException e) {
			System.err.println("Error writing to products file: " + e.getMessage());
		}
	}

	// Method that generates the seller flat file
	private static void generateSellerFile(List<Seller> seller) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("Sellers.txt"))) {
			for (Seller sellers : seller) {
				writer.write(sellers.documentType + "," + sellers.documentNumber + "," + sellers.namesSeller + ","
						+ sellers.surnamesSeller + "\n");
			}

			// Completion message with the successful procedure
			System.out.println("Sellers file generated successfully.");

		}
		// Completion message with the procedure with error
		catch (IOException e) {
			System.err.println("Error writing to Sellers file: " + e.getMessage());
		}
	}

	// Method that generates the sales flat file
	public static void generateSalesFile(List<Sales> sales) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("Sales.txt"))) {
			for (Sales sales2 : sales) {

				writer.write(sales2.product.idProduct + "," + sales2.product.nameProduct + ","
						+ sales2.product.priceByUnit + "," + sales2.amount + "," + "," + sales2.seller.documentType
						+ ";" + sales2.seller.namesSeller + ";" + sales2.seller.surnamesSeller + ","
						+ sales2.seller.documentNumber + "," + sales2.totalSalesProduct + "\n");
			}
			// Completion message with the successful procedure
			System.out.println("Sales file generated successfully.");

			// Completion message with the procedure with error
		} catch (IOException e) {
			System.err.println("Error writing to Sales file: " + e.getMessage());

		}

	}
	
	// Method to create the CSV file with the information of products sold by quantity, ordered in descending order
	private static void generateProductSalesReportFile(List<Sales> sales) {
	    Map<String, Integer> productQuantities = new HashMap<>();

	    // Calculate the quantity and total per product sold
	    for (Sales sale : sales) {
	        String productName = sale.product.nameProduct;
	        int quantity = productQuantities.getOrDefault(productName, 0);
	        productQuantities.put(productName, quantity + sale.amount);
	    }

	    List<Map.Entry<String, Integer>> productList = new ArrayList<>(productQuantities.entrySet());
	    productList.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()));

	    // Generates the CSV file with the information of the products sold, separated by columns
	    try (BufferedWriter writer = new BufferedWriter(new FileWriter("ProductSalesReport.csv"))) {
	        // Write CSV file headers
	        writer.write("Nombre Producto;Precio\n");

	        // Write the information of the sold products to the CSV file
	        for (Map.Entry<String, Integer> entry : productList) {
	            // Find the corresponding product in sales
	            String productName = entry.getKey();
	            Sales productSale = sales.stream()
	                    .filter(sale -> sale.product.nameProduct.equals(productName))
	                    .findFirst()
	                    .orElse(null);

	            // brings the price of the product in the CSV file
	            if (productSale != null) {
	                writer.write(productName + ";" + productSale.product.priceByUnit + "\n");
	            }
	        }

	        System.out.println("Product sales report file generated successfully.");
	    } catch (IOException e) {
	        System.err.println("Error writing to Product sales report file: " + e.getMessage());
	    }
	}
	
	// Method that adds the sales made per seller and outputs them in a CSV file
	
	private static void generateSalesMenReportFile(List<Sales> sales) {
	    //Create a map to store total sales by seller
	    Map<String, Double> salesBySeller = new HashMap<>();

	    // Calculate total sales per seller
	    for (Sales sale : sales) {
	        String sellerName = sale.seller.namesSeller + " " + sale.seller.surnamesSeller;
	        double totalSales = salesBySeller.getOrDefault(sellerName, 0.0);
	        totalSales += sale.totalSalesProduct;
	        salesBySeller.put(sellerName, totalSales);
	    }

	    try (BufferedWriter writer = new BufferedWriter(new FileWriter("SalesMenReport.csv"))) {
	        writer.write("Nombre Vendedor;Total Vendido\n");

	        // Write sales totals by seller to CSV file
	        for (Map.Entry<String, Double> entry : salesBySeller.entrySet()) {
	            writer.write(entry.getKey() + ";" + entry.getValue() + "\n");
	        }
	        System.out.println("Salesmen report file generated successfully.");
	    } catch (IOException e) {
	        System.err.println("Error writing to Salesmen report file: " + e.getMessage());
	    }
	}
	
	
	// Method to generate sales files by seller
	private static void generateSalesBySellerFiles(List<Sales> sales) {
	    Map<String, List<Sales>> salesBySeller = new HashMap<>();

	    // Group sales by seller
	    for (Sales sale : sales) {
	        String sellerName = sale.seller.namesSeller + "_" + sale.seller.surnamesSeller;
	        if (!salesBySeller.containsKey(sellerName)) {
	            salesBySeller.put(sellerName, new ArrayList<>());
	        }
	        salesBySeller.get(sellerName).add(sale);
	    }

	    // Generate files per seller
	    for (Map.Entry<String, List<Sales>> entry : salesBySeller.entrySet()) {
	        String sellerName = entry.getKey();
	        List<Sales> sellerSales = entry.getValue();
	        generateSalesFileBySeller(sellerName, sellerSales);
	    }
	}

	// Method to generate sales file by seller
	private static void generateSalesFileBySeller(String sellerName, List<Sales> sales) {
	    String fileName = sellerName + "_Sales.txt";

	    try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
	        writer.write("ID Producto,Nombre Producto,Precio por unidad,Cantidad,Total\n");

	        //Write seller sales to file
	        for (Sales sale : sales) {
	            writer.write(sale.product.idProduct + "," + sale.product.nameProduct + "," + sale.product.priceByUnit +
	                    "," + sale.amount + "," + sale.totalSalesProduct + "\n");
	        }

	        System.out.println("Sales file for " + sellerName + " generated successfully.");
	    } catch (IOException e) {
	        System.err.println("Error writing to sales file for " + sellerName + ": " + e.getMessage());
	    }
	}
	
	
}
